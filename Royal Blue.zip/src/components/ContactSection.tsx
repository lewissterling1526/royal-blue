"use client";

import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { MapPin, Mail, Phone } from 'lucide-react';

const ContactSection = () => {
  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-6">Message Us</h2>
            <p className="text-gray-600 mb-8">Have a question or ready to start? Send us a message and we'll get back to you shortly.</p>
            
            <form className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input placeholder="Full Name" className="h-12" />
                <Input placeholder="Email Address" type="email" className="h-12" />
              </div>
              <Input placeholder="Phone Number" className="h-12" />
              <Textarea placeholder="How can we help you?" className="min-h-[150px]" />
              <Button className="w-full h-12 bg-primary text-white hover:bg-primary/90 text-lg">Send Message</Button>
            </form>
          </div>

          <div className="space-y-8">
            <div className="aspect-video bg-gray-100 rounded-2xl overflow-hidden relative border-4 border-white shadow-xl">
              {/* Placeholder for Google Map */}
              <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-400 bg-gray-200">
                <MapPin size={48} className="mb-2 text-secondary" />
                <span className="font-medium">Interactive Map Placeholder</span>
                <span className="text-sm">123 Service St, Business City, ST 12345</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="flex flex-col items-center text-center p-4 rounded-xl bg-gray-50">
                <Phone className="text-secondary mb-2" size={24} />
                <div className="text-sm font-bold text-primary">(555) 123-4567</div>
              </div>
              <div className="flex flex-col items-center text-center p-4 rounded-xl bg-gray-50">
                <Mail className="text-secondary mb-2" size={24} />
                <div className="text-sm font-bold text-primary">hello@servicepro.com</div>
              </div>
              <div className="flex flex-col items-center text-center p-4 rounded-xl bg-gray-50">
                <MapPin className="text-secondary mb-2" size={24} />
                <div className="text-sm font-bold text-primary">Main HQ, City</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;