"use client";

import React from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  { q: "How does the quote process work?", a: "Simply fill out our online form or give us a call. We'll assess your needs and provide a detailed, transparent estimate within 24 hours." },
  { q: "What areas do you currently serve?", a: "We provide services across the entire metropolitan area and surrounding suburbs within a 50-mile radius." },
  { q: "Are your technicians certified and insured?", a: "Yes, all our professionals are fully certified, background-checked, and we carry comprehensive liability insurance for your peace of mind." },
  { q: "Do you offer emergency after-hours support?", a: "Absolutely. We have a dedicated emergency response team available 24/7, 365 days a year for urgent issues." },
  { q: "What kind of warranty do you provide?", a: "We stand behind our work with a 100% satisfaction guarantee and a minimum 12-month warranty on all parts and labor." },
];

const FAQ = () => {
  return (
    <section id="faq" className="py-24 bg-gray-50">
      <div className="container mx-auto px-4 max-w-3xl">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">Frequently Asked Questions</h2>
          <p className="text-gray-600">Everything you need to know about our services and process.</p>
        </div>

        <Accordion type="single" collapsible className="w-full space-y-4">
          {faqs.map((faq, index) => (
            <AccordionItem key={index} value={`item-${index}`} className="bg-white border rounded-xl px-6">
              <AccordionTrigger className="text-left font-bold text-primary hover:no-underline py-6">
                {faq.q}
              </AccordionTrigger>
              <AccordionContent className="text-gray-600 pb-6 leading-relaxed">
                {faq.a}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

export default FAQ;