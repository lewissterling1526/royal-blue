"use client";

import React from 'react';
import { Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-primary text-white pt-20 pb-10">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-16">
          <div>
            <div className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 bg-secondary rounded flex items-center justify-center">
                <span className="text-primary font-bold">S</span>
              </div>
              <span className="text-xl font-bold tracking-tight">SERVICE<span className="text-secondary">PRO</span></span>
            </div>
            <p className="text-white/60 leading-relaxed mb-6">
              Providing world-class professional services with a commitment to excellence and customer satisfaction for over 25 years.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-secondary hover:text-primary transition-all">
                <Facebook size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-secondary hover:text-primary transition-all">
                <Twitter size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-secondary hover:text-primary transition-all">
                <Instagram size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-secondary hover:text-primary transition-all">
                <Linkedin size={18} />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-6 text-secondary">Quick Links</h3>
            <ul className="space-y-4 text-white/60">
              <li><a href="#services" className="hover:text-white transition-colors">Our Services</a></li>
              <li><a href="#testimonials" className="hover:text-white transition-colors">Client Reviews</a></li>
              <li><a href="#faq" className="hover:text-white transition-colors">Common Questions</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-6 text-secondary">Contact Info</h3>
            <ul className="space-y-4 text-white/60">
              <li className="flex items-start gap-3">
                <span className="text-secondary font-bold">A:</span>
                123 Service St, Business City, ST 12345
              </li>
              <li className="flex items-center gap-3">
                <span className="text-secondary font-bold">P:</span>
                (555) 123-4567
              </li>
              <li className="flex items-center gap-3">
                <span className="text-secondary font-bold">E:</span>
                hello@servicepro.com
              </li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-white/10 text-center text-white/40 text-sm">
          © {new Date().getFullYear()} ServicePro Template. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;