"use client";

import React from 'react';
import { Phone, Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Navbar = () => {
  return (
    <>
      <nav className="fixed top-0 w-full z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
        <div className="container mx-auto px-4 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-secondary font-bold text-xl">S</span>
            </div>
            <span className="text-xl font-bold text-primary tracking-tight">SERVICE<span className="text-secondary">PRO</span></span>
          </div>
          
          <div className="hidden md:flex items-center gap-8">
            <a href="#services" className="text-sm font-medium text-primary/80 hover:text-secondary transition-colors">Services</a>
            <a href="#testimonials" className="text-sm font-medium text-primary/80 hover:text-secondary transition-colors">Testimonials</a>
            <a href="#faq" className="text-sm font-medium text-primary/80 hover:text-secondary transition-colors">FAQ</a>
            <Button className="bg-primary text-white hover:bg-primary/90">Get a Quote</Button>
          </div>

          <button className="md:hidden text-primary">
            <Menu size={24} />
          </button>
        </div>
      </nav>

      {/* Sticky Mobile Call Button */}
      <div className="md:hidden fixed bottom-6 right-6 z-50">
        <Button className="rounded-full w-14 h-14 bg-secondary text-primary shadow-xl hover:scale-105 transition-transform">
          <Phone size={24} fill="currentColor" />
        </Button>
      </div>
    </>
  );
};

export default Navbar;