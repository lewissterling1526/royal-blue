"use client";

import React from 'react';
import { Shield, Zap, Settings, Wrench, Briefcase, Search } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const services = [
  { title: 'Specialized Service 1', icon: Shield, desc: 'Comprehensive protection and maintenance for your critical assets.' },
  { title: 'Strategic Consulting', icon: Briefcase, desc: 'Expert advice to optimize your operations and reduce long-term costs.' },
  { title: 'Emergency Repairs', icon: Zap, desc: 'Rapid response team available 24/7 for all urgent service requirements.' },
  { title: 'System Optimization', icon: Settings, desc: 'Fine-tuning your existing infrastructure for maximum efficiency.' },
  { title: 'Technical Support', icon: Wrench, desc: 'Hands-on technical assistance from certified industry professionals.' },
  { title: 'Quality Audits', icon: Search, desc: 'Detailed inspections to ensure compliance with the highest standards.' },
];

const ServicesGrid = () => {
  return (
    <section id="services" className="py-24 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">Our Premium Services</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">We provide a wide range of professional solutions tailored to meet your specific needs with precision and care.</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-none bg-white">
              <CardHeader>
                <div className="w-14 h-14 rounded-xl bg-primary/5 flex items-center justify-center mb-4 group-hover:bg-secondary/20 transition-colors">
                  <service.icon className="text-primary group-hover:text-secondary transition-colors" size={28} />
                </div>
                <CardTitle className="text-xl text-primary">{service.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 leading-relaxed">{service.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesGrid;