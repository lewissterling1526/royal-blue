"use client";

import React from 'react';
import { Star, Quote } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const testimonials = [
  { name: 'Alice Johnson', role: 'Homeowner', text: 'The team was incredibly professional and efficient. They solved our issue in record time!' },
  { name: 'Bob Smith', role: 'Business Owner', text: 'I have been using their services for years. Reliability is their middle name. Highly recommended.' },
  { name: 'Charlie Davis', role: 'Property Manager', text: 'Exceptional attention to detail. They go above and beyond to ensure everything is perfect.' },
  { name: 'Diana Prince', role: 'Operations Director', text: 'Their strategic consulting saved us thousands in operational costs this year alone.' },
  { name: 'Eve Wilson', role: 'Local Resident', text: 'Fast, friendly, and fair pricing. It is hard to find service providers this honest nowadays.' },
];

const Testimonials = () => {
  return (
    <section id="testimonials" className="py-24 bg-white overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">What Our Clients Say</h2>
          <div className="flex justify-center gap-1 text-secondary">
            {[...Array(5)].map((_, i) => <Star key={i} size={20} fill="currentColor" />)}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((t, index) => (
            <Card key={index} className="relative border-gray-100 shadow-sm hover:shadow-md transition-shadow">
              <CardContent className="pt-12">
                <Quote className="absolute top-6 left-6 text-secondary/20" size={40} />
                <p className="text-gray-600 italic mb-6 relative z-10">"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                    {t.name[0]}
                  </div>
                  <div>
                    <div className="font-bold text-primary">{t.name}</div>
                    <div className="text-sm text-gray-500">{t.role}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;