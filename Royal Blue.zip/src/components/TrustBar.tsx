"use client";

import React from 'react';
import { Users, Star, Award } from 'lucide-react';

const TrustBar = () => {
  const stats = [
    { icon: Users, label: '10K+ Happy Clients', sub: 'Trusted across the region' },
    { icon: Star, label: '5.0 Star Rating', sub: 'Based on 2,500+ reviews' },
    { icon: Award, label: '25+ Years Experience', sub: 'Industry leading expertise' },
  ];

  return (
    <section className="py-12 bg-primary">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="flex items-center gap-4 justify-center md:justify-start">
              <div className="w-12 h-12 rounded-full bg-secondary/20 flex items-center justify-center">
                <stat.icon className="text-secondary" size={24} />
              </div>
              <div>
                <div className="text-white font-bold text-lg leading-tight">{stat.label}</div>
                <div className="text-white/60 text-sm">{stat.sub}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrustBar;